# Deployment and execution safety gates

1. Verify actual IBM Bob tool availability. Do not assume shell access, TMS/STMS, CTS, ADT or FLP admin connector.
2. Before system-changing action require exact SID/client, affected components/transports, source and target, action-specific approval, change ticket, window, owner and documented recovery. Stop on mismatch.
3. No credentials or access tokens in workbook or output artifacts. Prefer linked enterprise secret management and least-privilege identities.
4. Do not autonomously execute changes in production. Request approval for every material production change; follow organization change controls.
5. PASS requires observed execution evidence. FAIL requires observed divergence. BLOCKED = missing tool/approval/access. NOT_RUN = not attempted. INCONCLUSIVE = insufficient evidence.
6. Rollback is a distinct high-risk operation: never trigger automatically after a failed smoke test. Escalate to authorized human decision-maker.
7. Never imply deployment or human sign-off merely from generated artifacts.

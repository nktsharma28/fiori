# Unified workbook input contract

Use the same Phase 8 Excel workbook for GENERATE, EXECUTE and FULL. `01 Control` Mode may be `ASK`; the explicit runtime selection controls the workflow. Never infer approval from a Mode cell.

- START HERE: user guidance.
- 01 Control: application ID, project, target system/client, release ID and selected mode.
- 02 Landscape: destination SID/client, URL/system alias, connectivity mechanism.
- 03 Release Scope: app objects, source/transport references and release owner.
- 04 FLP Catalog Roles: semantic objects/actions, mapping, catalog/space/page and PFCG role.
- 05 Transport Plan: dependencies, sequence, target, recovery and approvals.
- 06 Smoke Tests: tests with preconditions, steps, expected results and approved runner.
- 07 Support Monitoring: monitored components, thresholds and runbooks.
- 08 Incidents Rollback: triage, escalation, recovery plans.
- 09 Execution Plan: run scope, target environment, action approvals, runners, maintenance window.
- 10 Output Register: expected artifact names.
- 11 Signoff: human owner decisions; never synthesize approval.

GENERATE requires control application/project and meaningful release scope; technical gaps must be flagged, not hallucinated. EXECUTE requires a valid environment, actionable non-example test or approved action, execution-plan record, relevant approvals and an available external runner. FULL requires generation inputs then a separately approved execution gate. A completed template does not prove connected system access. Samples must be replaced and marked non-example before any execution.

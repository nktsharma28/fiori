---
name: sap-fiori-deployment-support
description: Use for SAP Fiori Phase 8 deployment and support through IBM Bob, including FLP catalogs, spaces/pages, roles, target mappings, transport readiness, smoke tests, monitoring and incidents. Prompt for GENERATE, EXECUTE or FULL mode and use one unified Excel input workbook for all modes.
---

# SAP Fiori Phase 8 — Unified Deployment and Support

## Operating contract
Use **one workbook** (`assets/SAP_Fiori_Phase8_Unified_Input_Template.xlsx`) for `GENERATE`, `EXECUTE`, and `FULL`. Read `references/input-contract.md` and `references/execution-gates.md` before operating. Never invent SAP tool availability, transport outcomes, observed results, access permissions or sign-offs.

## Step 1 — Always offer mode selection when not specified
Before processing inputs, prompt exactly in conversational form (or a native menu if Bob supports it):

> Choose Phase 8 mode: **1 — GENERATE** (create FLP deployment artifacts, release plan, smoke tests and support runbooks without system changes), **2 — EXECUTE** (validate and run existing approved, supported deployment checks), or **3 — FULL** (generate, verify prerequisites, obtain action-specific approval, then execute supported checks). Which option do you want?

Accept mode names or 1/2/3 case-insensitively. If the user already selected a mode in this request, do not ask again. Do not treat an Excel `Mode` value as permission to execute. If mode selection conflicts with workbook, resolve the conflict before processing. Ask for the **same Excel workbook** and any referenced application/landscape documentation; use the bundled blank workbook if needed.

## Step 2 — Validate unified workbook
Run `python scripts/validate_phase8_input.py <workbook> --mode GENERATE|EXECUTE|FULL` when code execution is available; otherwise apply the checks described in `references/input-contract.md`. The validator checks structure and mode-relevant fields; it does **not** authenticate to SAP or prove execution readiness. Separate genuine input rows from `EXAMPLE`/sample rows. Do not execute example cases. Missing mandatory items become explicit input gaps; avoid inventing system aliases, roles, FLP intents, transport IDs, service URLs and approval references.

## GENERATE workflow
1. Read application IDs, Fiori type, source/transport references, S/4HANA version, FLP conventions, service bindings, requirements and prior Phase 5–7 evidence as available.
2. Generate reviewable FLP content plan: semantic object/action, target mapping, catalog, space/page, app descriptor, navigation intent and role-to-app mapping. Distinguish SAP platform differences; do not assume an ABAP service or FLP API exists without evidence.
3. Produce deployment prerequisites and dependencies: UI app, OData service, ICF/authorization where applicable, content transport objects, catalog/role assignment prerequisites, deployment sequence and backout approach.
4. Generate smoke tests for FLP launch, role visibility, navigation, OData metadata/reads, core UI read-only actions and monitoring checks. Use supplied real URLs/selectors only; otherwise mark them placeholders.
5. Prepare change plan, release checklist, support runbook, incident triage guide, RACI, evidence template and explicit open issues. Output `Phase8/Generated/` manifest and test plans. Never claim generated commands were executed.

## EXECUTE workflow
1. Read approved deployment and test plan; validate environment, software version, credential-free runtime connection, transport/deployment tools, FLP/browser and HTTP runners, test identities, maintenance window and approvals.
2. By default perform **non-mutating verification only** (readiness checks and smoke tests). Before any transport release/import, FLP catalog/role change, application deploy, production action, write test or rollback, obtain **explicit fresh action-specific user approval** including exact SID/client, affected objects, impact, change record and recovery plan. If approval/tooling is absent: mark action BLOCKED and continue safe checks.
3. Never assume IBM Bob itself has a deployment API. Call only integrations actually exposed in the runtime; do not invent `execute_command`/ADT/TMS calls. Do not handle credentials in chat, Excel or logs. Production is not a default test target. Observe separation of duties; avoid role escalation.
4. Execute only approved in-scope cases using verified available tools, capture timestamp, target, invocation ID, actual observation and redact sensitive data from logs/screenshots. On unavailable runner or refused access, status BLOCKED—not PASS.
5. Record test status as PASS/FAIL/BLOCKED/NOT_RUN/INCONCLUSIVE with evidence. Produce deployment readiness result, smoke-test matrix, incident/defect references, support handover and pending approvals. Never fabricate deployment success.

## FULL workflow
Generate all artifacts first, review prerequisite and risk checklist with user, then request authorization separately for each material system-changing operation. After approval, execute supported and allowed actions and consolidate results. If tooling or SAP connectivity is missing, retain generated artifacts, record execution BLOCKED and explain the precise integration gap. Do not issue a final go-live sign-off; present readiness for human approval.

## Outputs
- Generation: `flp-content-plan.csv`, `role-access-matrix.csv`, `deployment-readiness.md`, `transport-plan.csv`, `smoke-tests.csv`, `monitoring-plan.csv`, `incident-runbook.md`, `release-manifest.json`, `handover-checklist.md`.
- Execution (only observed): `execution-results.csv`, `evidence-index.csv`, `issues.csv`, `deployment-report.md`, `support-handover.md`.
- Distinguish prepared, approved, invoked, completed, verified and human-signed-off states.

## Bundled resources
- `assets/SAP_Fiori_Phase8_Unified_Input_Template.xlsx`: same shared input for all modes.
- `references/input-contract.md`: input mapping and validation.
- `references/execution-gates.md`: tool/authorization and result handling.
- `scripts/validate_phase8_input.py`: local workbook validation; no system access.

#!/usr/bin/env python3
import argparse, sys
from openpyxl import load_workbook
SHEETS=['01 Control','02 Landscape','03 Release Scope','04 FLP Catalog Roles','05 Transport Plan','06 Smoke Tests','07 Support Monitoring','08 Incidents Rollback','09 Execution Plan','10 Output Register','11 Signoff']
def real(v):
 s=str(v or '').strip()
 return bool(s) and not s.upper().startswith(('EXAMPLE','PENDING','NOT SCHEDULED','NOT READY'))
def valid_rows(ws):
 for row in ws.iter_rows(min_row=2, values_only=True):
  if any(v is not None for v in row) and not any('EXAMPLE' in str(v).upper() for v in row) and not any(str(v).upper()=='YES' for v in row[-1:]):
   yield row
p=argparse.ArgumentParser();p.add_argument('workbook');p.add_argument('--mode',choices=['GENERATE','EXECUTE','FULL'],required=True);a=p.parse_args()
w=load_workbook(a.workbook,data_only=True)
errors=[]
for sheet in SHEETS:
 if sheet not in w.sheetnames: errors.append('Missing worksheet: '+sheet)
if errors:
 print('\n'.join(errors));sys.exit(1)
control={str(w['01 Control'].cell(i,1).value):w['01 Control'].cell(i,2).value for i in range(2,w['01 Control'].max_row+1)}
for key in ['Project ID','Application ID','Release ID']:
 if not real(control.get(key)):errors.append('01 Control: enter a real '+key)
mode=str(control.get('Selected Mode') or 'ASK').upper()
if mode not in ('ASK',a.mode):errors.append('01 Control: mode conflicts with selected mode')
if not list(valid_rows(w['03 Release Scope'])):errors.append('03 Release Scope: add at least one real, non-example release-scope row')
if a.mode=='EXECUTE':
 for key in ['SAP System ID','SAP Client']:
  if not real(control.get(key)):errors.append('01 Control: '+key+' required for EXECUTE')
 for sheet in ['02 Landscape','06 Smoke Tests','09 Execution Plan']:
  if not list(valid_rows(w[sheet])):errors.append(sheet+': real non-example data required for EXECUTE')
if a.mode=='FULL' and not list(valid_rows(w['09 Execution Plan'])):
 print('WARNING: FULL generation can proceed, but execution blocked until approved plan and connectivity are provided')
for e in errors:print('ERROR:',e)
if errors: sys.exit(1)
print('Workbook structure valid for',a.mode,'; SAP access/approvals/runability NOT verified')

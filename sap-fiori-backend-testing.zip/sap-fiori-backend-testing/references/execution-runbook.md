# Phase 5 execution runbook

## Discovery
Verify actual tools before invoking them: IBM Bob capabilities, Eclipse ADT logged-in session, permitted test automation CLI/REST interfaces, and Postman/Newman or pytest. Do not construct an ADT endpoint by analogy. Ask for the approved target/system if absent.

## Gating
1. Scope authorized DEV system, client, packages, identity and test IDs.
2. Validate manifest and check deployment/activation, data scope and permissions.
3. Run READ_ONLY tests first; record evidence from actual tool output.
4. Require separate explicit approval for REVERSIBLE_WRITE tests, including cleanup and rollback.
5. Never perform DESTRUCTIVE tests in this skill.

## Manual ADT fallback
When direct runner unavailable, instruct the developer to open the appropriate ABAP Unit test class in Eclipse ADT, choose Run As > ABAP Unit Test, collect observed results/export, and provide evidence for reconciliation. Status remains NOT_RUN until results are imported and inspected.

## Result row
`test_id,status,runner,started_at_utc,ended_at_utc,assertion_summary,evidence_file,defect_id,cleanup_status`

Use `BLOCKED` for absent access, unsupported runner, unapproved write or missing artifact. Use `FAIL` only for a test that ran and violated its assertion. Include sanitized evidence and never infer success from missing error messages.

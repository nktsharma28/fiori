# Developer handoff checklist

1. Confirm TDD, ABAP release and SAP edition; list known vs missing signatures.
2. Map each test to requirement/role, dataset and expected assertion.
3. Review the generated ABAP classes for syntax and released API compatibility in ADT; activate manually after approval.
4. Import API test collection in a trusted runner and fill *local* environment variables via secret storage.
5. Confirm DEV-only target, isolation, write-test approval and cleanup before running.
6. Deliver manifest and artifact paths to `sap-fiori-test-executor`.

## Sample test-case CSV columns
`test_id,requirement_id,type,scenario,preconditions,test_data,steps,expected_result,effect,approval_required,cleanup,artifact_path`

## Developer-ready vs verified
- `NEEDS_ADAPTATION`: names, types, SDK release or actual service metadata missing.
- `READY_FOR_EXECUTION`: source/static checks passed; not proof of activation.
- `EXECUTED`: only when separate execution evidence exists.

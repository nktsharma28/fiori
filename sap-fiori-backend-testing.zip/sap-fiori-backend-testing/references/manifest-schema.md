# Phase 5 portable test manifest contract (v1)

This contract passes test intent from the generator to the executor; it does **not** grant execution authorization.

Required root fields: `schema_version` ("1"), `project`, `target_environment` ("DEV"), `tests` (non-empty array).

Each test requires:
- `id`: unique stable identifier
- `requirement_id`: mapping back to a requirement/TDD item
- `category`: one of `ABAP_UNIT`, `CDS`, `RAP`, `ODATA`, `INTEGRATION`, `AUTHORIZATION`
- `execution_method`: e.g. `ADT_ABAP_UNIT`, `POSTMAN`, `PYTEST`, or `MANUAL` (must be verified before execution)
- `effect`: `READ_ONLY`, `REVERSIBLE_WRITE`, `DESTRUCTIVE`
- `requires_approval`: boolean (true for every write)
- `prerequisites`: array of strings
- `expected_result`: non-empty assertion statement
- `status`: `NOT_RUN` when generated
- `artifact_path`: code or collection file path, relative to bundle

Optional: `object_name`, `endpoint_template`, `roles`, `cleanup`, `test_data_reference`, `notes`.

Minimal example:
```json
{
  "schema_version": "1",
  "project": "sample-fiori-app",
  "target_environment": "DEV",
  "tests": [
    {
      "id": "ODATA-001",
      "requirement_id": "REQ-001",
      "category": "ODATA",
      "execution_method": "POSTMAN",
      "effect": "READ_ONLY",
      "requires_approval": false,
      "prerequisites": ["Approved DEV service URL and read permission"],
      "expected_result": "Metadata contains required declared entity set and key",
      "status": "NOT_RUN",
      "artifact_path": "api/collection.postman_collection.json"
    }
  ]
}
```

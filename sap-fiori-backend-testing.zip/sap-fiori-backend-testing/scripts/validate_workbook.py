#!/usr/bin/env python3
"""Validate Phase 5 single workbook without making SAP calls. Demo row 4 is ignored."""
import argparse,sys
from openpyxl import load_workbook
SHEETS=['00 Control','01 Specifications','02 CDS RAP Objects','03 OData Services','04 Test Scenarios','05 Test Data Roles','06 Executor Setup','07 Execution Plan','08 Output Register']
def records(ws):
 headers=[c.value for c in ws[3]]
 return [dict(zip(headers,[c.value for c in row])) for row in ws.iter_rows(min_row=5) if any(c.value is not None and str(c.value).strip() for c in row)]
def value(row,prefix):
 return next((v for k,v in row.items() if k.startswith(prefix)),None)
def validate(path,mode):
 wb=load_workbook(path,data_only=True); errors=[]
 for sh in SHEETS:
  if sh not in wb.sheetnames: errors.append('missing sheet: '+sh)
 if errors:return errors
 ctrl=records(wb['00 Control']); specs=records(wb['01 Specifications']); execs=records(wb['06 Executor Setup']); plans=records(wb['07 Execution Plan']); tests=records(wb['04 Test Scenarios'])
 if not ctrl: errors.append('00 Control: enter project/application in row 5 or later (row 4 is example)')
 else:
  for key in ('Project ID','Application ID'):
   if not value(ctrl[0],key):errors.append('00 Control: missing '+key)
 if mode in ('GENERATE','FULL'):
  if not specs:errors.append('01 Specifications: enter at least one real requirement in row 5+')
  if specs and any(not value(r,'Requirement ID') or not value(r,'Requirement / Acceptance Criterion') for r in specs):errors.append('01 Specifications: requirement ID and acceptance criterion needed')
  objs=records(wb['02 CDS RAP Objects']); svcs=records(wb['03 OData Services'])
  if not objs and not svcs:errors.append('02 CDS RAP Objects / 03 OData Services: provide technical definitions or expect NEEDS_ADAPTATION scaffolds')
 if mode=='EXECUTE':
  if not ctrl or not value(ctrl[0],'Manifest Path'):errors.append('00 Control: Manifest Path required for EXECUTE')
  if not tests and not plans:errors.append('04 Test Scenarios or 07 Execution Plan: approved test IDs required')
 if mode in ('EXECUTE','FULL'):
  if not execs:errors.append('06 Executor Setup: runner and DEV system data missing; execution will be BLOCKED')
  else:
   r=execs[0]
   for prefix in ('Environment','SAP SID','Client','Runner Type','Runner Command'):
    if not value(r,prefix):errors.append('06 Executor Setup: missing '+prefix)
   if value(r,'Environment')!='DEV':errors.append('06 Executor Setup: only DEV execution allowed')
  if not plans:errors.append('07 Execution Plan: approved selected test IDs missing; execution will be BLOCKED')
 return errors
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('workbook');p.add_argument('--mode',required=True,choices=['GENERATE','EXECUTE','FULL']);a=p.parse_args()
 try:errs=validate(a.workbook,a.mode)
 except Exception as e:print('INVALID:',e);sys.exit(2)
 for e in errs:print('MISSING/BLOCKED:',e)
 if errs:sys.exit(1)
 print('VALID: workbook mode '+a.mode);sys.exit(0)

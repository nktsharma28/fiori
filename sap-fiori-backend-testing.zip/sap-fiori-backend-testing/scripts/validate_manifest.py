#!/usr/bin/env python3
"""Validate the shared Phase 5 generator-to-executor JSON manifest. No SAP access."""
import json
import sys
from pathlib import Path

CATEGORIES = {"ABAP_UNIT", "CDS", "RAP", "ODATA", "INTEGRATION", "AUTHORIZATION"}
EFFECTS = {"READ_ONLY", "REVERSIBLE_WRITE", "DESTRUCTIVE"}


def validate(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    errors = []
    for key in ("schema_version", "project", "target_environment", "tests"):
        if key not in data:
            errors.append(f"missing root: {key}")
    if data.get("schema_version") != "1":
        errors.append("unsupported schema_version (expected '1')")
    if data.get("target_environment") != "DEV":
        errors.append("target_environment must be DEV")
    if not isinstance(data.get("project"), str) or not data.get("project", "").strip():
        errors.append("project must be a nonempty string")
    tests = data.get("tests")
    if not isinstance(tests, list) or not tests:
        errors.append("tests must be a nonempty array")
        tests = []
    ids = set()
    for i, t in enumerate(tests):
        loc = f"tests[{i}]"
        if not isinstance(t, dict):
            errors.append(f"{loc} must be an object")
            continue
        for key in ("id", "requirement_id", "execution_method", "expected_result", "artifact_path"):
            if not isinstance(t.get(key), str) or not t.get(key, "").strip():
                errors.append(f"{loc}.{key} must be nonempty string")
        tid = t.get("id")
        if isinstance(tid, str):
            if tid in ids:
                errors.append(f"duplicate id: {tid}")
            ids.add(tid)
        if t.get("category") not in CATEGORIES:
            errors.append(f"{loc}.category invalid")
        if t.get("effect") not in EFFECTS:
            errors.append(f"{loc}.effect invalid")
        if not isinstance(t.get("requires_approval"), bool):
            errors.append(f"{loc}.requires_approval must be boolean")
        if t.get("effect") != "READ_ONLY" and t.get("requires_approval") is not True:
            errors.append(f"{loc} write test must require approval")
        if not isinstance(t.get("prerequisites"), list) or not all(isinstance(x, str) for x in t.get("prerequisites", [])):
            errors.append(f"{loc}.prerequisites must be string array")
        if t.get("status") != "NOT_RUN":
            errors.append(f"{loc}.status should be NOT_RUN in handoff manifest")
        artifact_path = t.get("artifact_path", "")
        if isinstance(artifact_path, str) and (Path(artifact_path).is_absolute() or ".." in Path(artifact_path).parts):
            errors.append(f"{loc}.artifact_path must be relative and not traverse parents")
    return errors


def main():
    if len(sys.argv) != 2:
        print("Usage: validate_manifest.py test-manifest.json", file=sys.stderr)
        return 2
    try:
        errors = validate(sys.argv[1])
    except (OSError, json.JSONDecodeError) as exc:
        print(f"INVALID: {exc}", file=sys.stderr)
        return 1
    if errors:
        for e in errors:
            print(f"INVALID: {e}", file=sys.stderr)
        return 1
    print("VALID: Phase 5 manifest schema v1")
    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: sap-fiori-backend-testing
description: Unified IBM Bob SAP Fiori Phase 5 OData and backend testing skill. Prompt users to select GENERATE, EXECUTE or FULL; use one shared Excel input template to generate ABAP Unit, CDS, RAP and OData V2/V4 tests, execute approved nonproduction tests through available SAP ADT and API runners, and report evidence-backed results.
---

# SAP Fiori Phase 5 — Unified Backend and OData Testing

## First interaction: select operation
When invoked without an explicit mode, **show this selection and wait for the user's reply before proceeding**:

> Choose Phase 5 testing mode:
> **1 — GENERATE:** Generate ABAP Unit, CDS test-double, RAP and OData test code/cases. No live SAP connection and no test execution.
> **2 — EXECUTE:** Run existing approved tests in an authorized SAP S/4HANA development environment with verified ADT/API tools and collect real results.
> **3 — FULL:** Generate tests and manifest; assess execution readiness; execute only the approved supported tests; report results and blockers.

Accept `1`, `2`, `3` or `GENERATE`, `EXECUTE`, `FULL` (case-insensitive). If mode was specified in the prompt, do not ask again. If the user explicitly asks to use the workbook mode, take it from `00 Control`, `Mode` (only `GENERATE`, `EXECUTE`, `FULL`); if conflicting, ask which instruction has priority. Do not assume an `ask_followup_question` function is available: use Bob's ordinary interactive conversation. Do not assume calling this skill provides SAP access.

## Single shared input workbook for ALL modes
Use `assets/SAP_Fiori_Phase5_Unified_Input_Template.xlsx`. Read the user's completed copy, not the bundled empty example. Every mode reads the SAME workbook; do not require a separate executor workbook. The sheets are `START HERE`, `00 Control`, `01 Specifications`, `02 CDS RAP Objects`, `03 OData Services`, `04 Test Scenarios`, `05 Test Data Roles`, `06 Executor Setup`, `07 Execution Plan`, `08 Output Register`.

Validate using `python scripts/validate_workbook.py <workbook.xlsx> --mode GENERATE|EXECUTE|FULL` when a command runner is available, else manually. Identify missing sheet/column/row, distinguish empty template/example rows from user inputs, and never infer SID, endpoints, ADT permissions or ABAP signatures. Do not store passwords, cookies or bearer tokens in the workbook.

### Mode-specific input gates
- **GENERATE**: Require project/application ID and source functional/TDD material, plus relevant CDS/RAP/OData object definitions for executable code. With incomplete signatures generate explicitly labeled `NEEDS_ADAPTATION` skeletons and document gaps. No SAP connection required.
- **EXECUTE**: Require generated `test-manifest.json`, test artifacts (activated where applicable), nonproduction DEV target SID/client, verified runner, selected approved test IDs and access/role. Missing connectivity -> `EXECUTION_BLOCKED`; do not pretend execution occurred.
- **FULL**: Start with GENERATE requirements. After producing artifacts, inspect execution prerequisites and approvals; run only approved supported tests. Missing runner/access -> deliver generation artifacts and `EXECUTION_BLOCKED` report.

## GENERATE workflow
Read `references/manifest-schema.md` and `references/generation-handoff.md`.
1. Read workbook, TDD, requirements, CDS DDL, behavior definitions/implementations, OData metadata and service bindings, integration specs and SAP/ABAP release constraints. Trace every requirement to test IDs, method and expected assertions. Don't fabricate object names or ADT APIs.
2. Create `test-cases.csv`, `traceability.csv`, `coverage-summary.md` covering applicable ABAP Unit, CDS (with `CL_CDS_TEST_ENVIRONMENT` only when release supports it), RAP behavior, OData V2/V4 metadata/queries/error handling, integration, negative, boundary, calculated fields and authorization cases.
3. Generate `abap/` real classes only from supplied actual signatures, otherwise labeled scaffolds. Generate `api/` Postman v2.1 or requested pytest suite with environment variable placeholders, assertions, CSRF handling for approved writes, and cleanup design. Never embed secrets or real personal data.
4. Build `test-manifest.json` meeting `references/manifest-schema.md` with all status `NOT_RUN`. Validate via `python scripts/validate_manifest.py <file>`. Create `README.md` for ADT activation, runner setup and handoff. Do not connect or execute any SAP tests in GENERATE.

## EXECUTE workflow
Read `references/manifest-schema.md` and `references/execution-runbook.md`.
1. Validate manifest and approved selection. Determine actual callable ADT/IBM Bob/API runner capability; do not invent Bob CLI, ADT endpoints or service credentials. Verify SAP **DEV** SID/client, test package, activated ABAP tests, service metadata, authorized identity, approved synthetic fixtures and evidence location. Production is outside this skill's execution scope.
2. Classify each case `READ_ONLY`, `REVERSIBLE_WRITE` or `DESTRUCTIVE`. Default to read-only. Require distinct explicit approval specifying SID/client, test IDs, side effects and cleanup for any write; block destructive tests. Approving EXECUTE/FULL as a mode alone does not authorize data changes.
3. Execute read-only ABAP Unit/CDS/RAP tests with verified available ADT runner and OData assertions with an authenticated HTTP/Postman/pytest runner; record assertion-level results. If only manual Eclipse ADT is available, give manual run steps and mark as `NOT_RUN` until actual results are supplied.
4. For each selected case record timestamp, runner, actual assertion, outcome `PASS`, `FAIL`, `BLOCKED`, `NOT_RUN` or `SKIPPED`, sanitized log/evidence reference and cleanup. Do not equate HTTP 200 with business-correct data.
5. Produce `execution-results.json`, `execution-report.md`, `defects.csv` and JUnit XML only where grounded in observed runner output. Include actual coverage, risk and blocked dependencies. Never fabricate execution evidence.

## FULL workflow
1. Follow GENERATE including static validation and manifest handoff.
2. Reconcile workbook execution plan with generated test IDs; present planned scope, target, effect classifications, runners and remaining gaps for authorization.
3. If runner is not connected, still deliver generated artifacts and `EXECUTION_BLOCKED` with exact setup steps. Otherwise apply EXECUTE preflight and run only explicitly approved, supported tests; require separate write approval.
4. Deliver all generation artifacts alongside the actual execution report, clearly separating generated/NOT_RUN and observed PASS/FAIL/BLOCKED.

## Guardrails and reporting
- Do not activate/deploy objects, install tools, change transports, execute production tests or change business data without proper separate authorization. Do not bypass SAP role restrictions.
- Never claim IBM Bob can automatically connect to ADT; confirm available functions first. Never print tokens or user personal data.
- If workbook has only illustrative examples, treat it as NOT POPULATED and ask for real inputs; keep any partial nondependent output explicitly provisional.
- Final summary: mode, workbook path, verified inputs, generated files, executed counts, evidence paths, unexecuted cases, defects, missing access and next actions.

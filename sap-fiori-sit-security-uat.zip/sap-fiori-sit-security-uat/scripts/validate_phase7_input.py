#!/usr/bin/env python3
"""Static readiness/structure checks for unified Phase 7 workbook. Never contacts SAP."""
import argparse
import sys
from openpyxl import load_workbook

SHEETS=['START HERE','01 Control','02 Landscape','03 Requirements','04 Integration Map','05 Test Cases','06 Role Matrix','07 Test Data','08 Execution Plan','09 UAT Approval','10 Output Register']
COLS={
 '01 Control':['Mode','Application ID','Business Process'],
 '02 Landscape':['Environment ID','Test Identity Alias (no credentials)','UI/API Runner','Allowlisted?'],
 '03 Requirements':['Requirement ID','Acceptance Criteria'],
 '05 Test Cases':['Test Case ID','Type','Test Steps','Expected Result'],
 '08 Execution Plan':['Test Case ID','Environment ID','Select for Run?','Approval Status','Runner / Tool Alias','Approval Reference'],
}
MODES={'ASK','GENERATE','EXECUTE','FULL'}

def nonempty(value):
    return value is not None and str(value).strip() != '' and str(value).strip().upper() not in {'TBD','EXAMPLE','N/A'}

def real_rows(ws,key):
    header=[c.value for c in ws[1]]
    if key not in header: return []
    idx=header.index(key)
    return [(n, [c.value for c in row]) for n,row in enumerate(ws.iter_rows(min_row=2),2) if len(row)>idx and nonempty(row[idx].value) and not str(row[idx].value).startswith('EXAMPLE')]

def validate(path, mode=None):
    wb=load_workbook(path,read_only=True,data_only=True)
    errors=[]; warnings=[]
    for sn in SHEETS:
        if sn not in wb.sheetnames: errors.append(f'Missing sheet: {sn}')
    for sn,cols in COLS.items():
        if sn not in wb.sheetnames:continue
        headers=[c.value for c in wb[sn][1]]
        for col in cols:
            if col not in headers:errors.append(f'{sn}: missing column {col}')
    if errors:return errors,warnings
    ctrl=wb['01 Control']; vals=[c.value for c in ctrl[2]]
    headers=[c.value for c in ctrl[1]]
    control=dict(zip(headers,vals))
    workbook_mode=(str(control.get('Mode') or 'ASK').strip().upper())
    if workbook_mode not in MODES:errors.append('01 Control!A2: Mode must be ASK, GENERATE, EXECUTE or FULL')
    selected=(mode or workbook_mode).upper()
    if selected=='ASK':
        warnings.append('Select 1 GENERATE, 2 EXECUTE or 3 FULL with IBM Bob before proceeding')
        return errors,warnings
    if mode and workbook_mode not in {'ASK',selected}:
        errors.append(f'01 Control!A2: workbook mode {workbook_mode} conflicts with runtime selection {selected}; ask user to resolve')
    if selected not in {'GENERATE','EXECUTE','FULL'}:errors.append('Invalid selected mode')
    for col in ('Application ID','Business Process'):
        if not nonempty(control.get(col)):errors.append(f'01 Control!{col}: required for {selected}')
    if str(control.get('Requester') or '').strip().upper()=='EXAMPLE':warnings.append('01 Control!Requester: example value remains')
    if selected in {'GENERATE','FULL'}:
        rows=real_rows(wb['03 Requirements'],'Requirement ID')
        if not rows:errors.append('03 Requirements: at least one requirement row required')
        for n,values in rows:
            hh=[c.value for c in wb['03 Requirements'][1]]
            d=dict(zip(hh,values))
            if not nonempty(d.get('Acceptance Criteria')):errors.append(f'03 Requirements!row {n}: acceptance criteria required')
    if selected in {'EXECUTE','FULL'}:
        cases=real_rows(wb['05 Test Cases'],'Test Case ID')
        if not cases:
            if selected=='EXECUTE':errors.append('05 Test Cases: approved existing cases required')
            else:warnings.append('05 Test Cases: no case rows yet; generate cases before execution readiness check')
        else:
            hh=[c.value for c in wb['05 Test Cases'][1]]
            for n,rr in cases:
                dd=dict(zip(hh,rr))
                if not nonempty(dd.get('Expected Result')):errors.append(f'05 Test Cases!row {n}: expected result missing')
                if not nonempty(dd.get('Test Steps')):errors.append(f'05 Test Cases!row {n}: test steps missing')
        plans=real_rows(wb['08 Execution Plan'],'Test Case ID')
        if not plans:warnings.append('08 Execution Plan: no execution scope; execution BLOCKED until approved')
        for n,rr in plans:
            hh=[c.value for c in wb['08 Execution Plan'][1]];dd=dict(zip(hh,rr))
            if str(dd.get('Select for Run?') or '').upper()=='YES':
                if str(dd.get('Approval Status') or '').upper()!='APPROVED' or not nonempty(dd.get('Approval Reference')):
                    warnings.append(f'08 Execution Plan!row {n}: approval missing; test BLOCKED')
        if not any(str(c.value or '').lower()=='yes' for row in wb['02 Landscape'].iter_rows(min_row=2) for c in row if c.column==10):
            warnings.append('02 Landscape: no explicitly allowlisted environment; execution BLOCKED')
        warnings.append('Live SAP connectivity, tool runners and explicit execution authorization require runtime verification')
    return errors,warnings

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('workbook')
    ap.add_argument('--mode',choices=['GENERATE','EXECUTE','FULL'])
    args=ap.parse_args()
    errors,warnings=validate(args.workbook,args.mode)
    for x in warnings:print('WARNING:',x)
    for x in errors:print('ERROR:',x)
    print('STRUCTURE VALID' if not errors else 'STRUCTURE INVALID')
    return 1 if errors else 0
if __name__=='__main__':sys.exit(main())

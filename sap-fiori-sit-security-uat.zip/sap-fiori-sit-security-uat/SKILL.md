---
name: sap-fiori-sit-security-uat
description: Generate, execute, and report SAP Fiori Phase 7 system integration (SIT), role-based security, and UAT tests through IBM Bob in GENERATE, EXECUTE, or FULL modes. Use for test plans, automation scripts, SAP landscape test runs, evidence, defect triage, and business sign-off preparation.
---

# SAP Fiori Phase 7 — Unified SIT, Security and UAT

## Contract
Use the **same** `assets/SAP_Fiori_Phase7_Unified_Input_Template.xlsx` workbook for all three modes. Read `references/workbook-contract.md` for sheet mapping and `references/reporting-contract.md` for output status rules. Never invent system access, credentials, tool integration, execution status, results, or stakeholder approvals.

Modes:
- `GENERATE`: Generate traceable, reviewable SIT, RBAC/security, and UAT test cases and executable test artifacts **where real interfaces and tool capabilities are known**; do not run against SAP.
- `EXECUTE`: Consume existing approved test cases and scripts, confirm prerequisites and tool connectivity, execute only authorized eligible cases, capture actual results and evidence. No generating fictional tests or test results.
- `FULL`: Generate, validate, review/approve execution scope, run supported tests, report findings and hand off UAT acceptance. This does not waive authorization checks.

## Step 1 — Interactive mode selection (mandatory)
When invoked, **before any test generation or execution**, present this concise choice to the user and wait for their answer. Do not proceed merely because the workbook contains a mode value. If the user has already explicitly selected a mode in the same request, acknowledge that choice and proceed without asking again. Do not require a special question tool; ask conversationally if the host has no menu tool.

> Choose Phase 7 operation: **1 — GENERATE** (create SIT, security and UAT cases; no SAP access), **2 — EXECUTE** (run approved existing cases using connected tools), or **3 — FULL** (generate, review readiness, then execute only approved cases). Which option should I use?

Accept `1`, `2`, `3` or mode names case-insensitively. For ambiguous answers, ask again. Store the selected mode as the **runtime selection**. The `01 Control` workbook Mode may be `ASK` or one of three modes. If a workbook mode disagrees with the explicit runtime selection, ask user to resolve the conflict before processing. Never silently override the workbook, and never treat a workbook mode as execution consent.

After mode selection, request the **same unified Excel workbook** (if not already provided), plus referenced TDD and supporting files. If missing, identify required worksheets and stop or offer the bundled blank template. Run `python scripts/validate_phase7_input.py <workbook> --mode <SELECTED_MODE>` when code access is available. Report all mode-relevant failures with sheet and row, and do not invent missing data. The validator checks **structure and safety readiness**, not actual SAP access.

### Input readiness and safety
1. Read `01 Control` and all relevant source attachments and prior phase outputs. Identify evidence for each requirement, interface, role and expected outcome; do not fabricate technical details.
2. Require explicit user approval of target SAP client/environment, test identities and test-case scope for live execution. Require **separate consent** for any create/change/delete of business data and a tested cleanup/rollback plan. Never use production for write tests.
3. Never collect or embed credentials, tokens or personal data in the workbook, manifest or logs. Use configured runtime identities and secret providers only.
4. Never grant roles, change PFCG assignments, alter transports or sign off UAT automatically.
5. If no SAP or browser runner is connected, GENERATE can still succeed; EXECUTE is `BLOCKED`; FULL produces generation outputs and marks execution `BLOCKED`, with no invented results.

## Step 2 — Load and normalize input
Read worksheets (`01 Control`, `02 Landscape`, `03 Requirements`, `04 Integration Map`, `05 Test Cases`, `06 Role Matrix`, `07 Test Data`, `08 Execution Plan`, `09 UAT Approval`). Apply selected-mode checks in `references/workbook-contract.md`. Missing mandatory fields become `INPUT_GAP` with sheet/row references; stop only the cases dependent on them. Sample rows labeled EXAMPLE must not be run. Map requirements to test IDs, interfaces, role IDs, environment IDs, data IDs. Prefer synthetic or approved nonproduction data.

## Step 3 — GENERATE
1. Build SIT coverage from functional specs, process diagrams, interface contracts, OData service bindings and upstream/downstream system boundaries. Cover normal flow, timeout, retries, idempotency, invalid payloads and reconciliation when applicable.
2. Build security cases from *supplied* role-action-resource matrix including positive permission, denied access, least privilege and segregation-of-duties checks where policy is supplied. Never invent authorization expectations.
3. Build UAT business journeys from acceptance criteria; include preconditions, exact steps, expected result, data refs, priority, owner and evidence request.
4. Generate automation code only for identified configured frameworks and real selectors/interfaces. Otherwise generate runnable scaffolds with clearly marked configuration gaps; do not claim ready-to-run.
5. Produce test inventory, requirements-to-case traceability, test data plan, automation plan, execution manifest JSON, and documented blockers.

## Step 4 — EXECUTE
1. Validate manifest, scope, environment allowlist, available IBM Bob/Context Studio/SAP/HTTP/browser runner tools, reachable target, authenticated test identity, preconditions, data and explicit approval. ADT is not a substitute for browser UI automation; choose an actual installed runner. Block unavailable test types.
2. Run only cases explicitly marked Approved and In Scope. Use nonproduction environment; read-only tests by default. For writes require authorization, transaction-safe cleanup/rollback and test-data isolation.
3. Store real timestamps, environment IDs, tool/run IDs, executed steps, observed results, screenshots/log references, and defect references with secrets/PII redacted.
4. Set status strictly: `PASS` only with supporting observation; `FAIL` for real observed mismatch; `BLOCKED` for missing prerequisites/tool/permission; `NOT_RUN` for unattempted tests; `INCONCLUSIVE` for insufficient evidence. Never convert BLOCKED to PASS.
5. On test runner errors, isolate environment failures from product defects; never silently skip. Restrict security checks to authorized test accounts and safe operations.

## Step 5 — FULL and reporting
FULL must perform GENERATE, show readiness gaps and proposed cases, pause for explicit execution approval and then call EXECUTE only with confirmed access. Selecting FULL is not approval to execute. Produce a consolidated report for SIT, security and UAT with totals, case-level evidence, open defects, risks, coverage and an explicit human sign-off section. UAT sign-off may be `Pending`, `Approved`, `Rejected` or `Conditional` only when backed by a named authorized approver and decision evidence; otherwise `Pending`.

## Deliverables
- `test-manifest.json`, `sit-cases.csv`, `security-cases.csv`, `uat-cases.csv`, `traceability.csv`, `data-requirements.csv`, `automation/` as applicable.
- On execution: `execution-results.csv`, `evidence-index.csv`, `defects.csv`, `consolidated-report.md`, `uat-approval-register.csv`.
- Clearly distinguish generated tests, run-tested scripts, executed business tests and human approvals.

## Resources
- `assets/SAP_Fiori_Phase7_Unified_Input_Template.xlsx` — fillable workbook (also provided separately for download).
- `references/workbook-contract.md` — detailed workbook mapping.
- `references/reporting-contract.md` — evidence/status/approval rules.
- `scripts/validate_phase7_input.py` — structural input validator; does not replace SAP execution.

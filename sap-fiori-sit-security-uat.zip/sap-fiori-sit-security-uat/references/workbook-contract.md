# Unified workbook contract for ALL modes

The **same spreadsheet**, `assets/SAP_Fiori_Phase7_Unified_Input_Template.xlsx`, is required in GENERATE, EXECUTE and FULL. Never ask for a second mode-specific workbook. The skill prompts for runtime mode selection first. `01 Control!A2` can be `ASK`, `GENERATE`, `EXECUTE`, or `FULL`; `ASK` means ask Bob to select. If workbook mode and runtime choice conflict, obtain clarification before proceeding. A mode selection does not authorize executing tests.

## Worksheet map
- `START HERE`: explanation, field requirements, safety and selection instructions.
- `01 Control`: application, business process, source documents, scope, optional mode, and approval flags. Flags are not independent approval evidence.
- `02 Landscape`: nonproduction environment alias, client, connection and test runner aliases, identity reference; do not store authentication secrets.
- `03 Requirements`: requirement IDs, acceptance criteria and provenance.
- `04 Integration Map`: source-to-target interface, contract and failure handling.
- `05 Test Cases`: proposed/approved SIT, SECURITY, UAT cases, assertions and reference IDs.
- `06 Role Matrix`: expected allowed/denied role-action-resource combinations.
- `07 Test Data`: synthetic/approved fixtures, assertions, write/cleanup controls.
- `08 Execution Plan`: case IDs, environment, explicitly approved scope and runner, approval reference.
- `09 UAT Approval`: human business decision evidence; `Pending` by default.
- `10 Output Register`: expected artifacts, produced status, and links/references.

## Mode requirements
**GENERATE**: workbook with `01 Control` application/process, requirements and acceptance criteria in `03 Requirements`; use integration/role/test-data sheets when respective cases are requested. Case seed rows optional. Execution worksheets remain present but may be blank or placeholders. Never access SAP or claim any test passed.

**EXECUTE**: same workbook with actual approved cases (`05 Test Cases`), mapped allowlisted nonproduction system and identity/runner (`02 Landscape`), approved selected cases and approval reference (`08 Execution Plan`), and relevant test data and role expectations (`06 Role Matrix`, `07 Test Data`). The skill needs **separate** execution authorization beyond workbook flags. Missing access or runner = BLOCKED.

**FULL**: same workbook with GENERATE inputs; generation runs first, then explicit approval must be obtained for reviewed test cases, target and safety plan before execution. Execution fields can be completed during the approval handoff. If no runner exists, report generated artifacts and BLOCKED execution.

## Validation and results
Run `scripts/validate_phase7_input.py path.xlsx --mode GENERATE|EXECUTE|FULL`. Header/row checks are deterministic; it cannot verify SAP access. Treat values starting `EXAMPLE` and demo accounts as placeholders, never real authorization. Avoid inventing PFCG roles, service endpoints, test outcomes, defect status or business sign-off. Output statuses: `PASS`, `FAIL`, `BLOCKED`, `NOT_RUN`, `INCONCLUSIVE`. Keep provenance and evidence IDs for each executed case.

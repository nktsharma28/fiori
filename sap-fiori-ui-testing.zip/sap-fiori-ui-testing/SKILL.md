---
name: sap-fiori-ui-testing
description: Unified IBM Bob SAP Fiori Phase 6 UI testing skill. Prompt for GENERATE, EXECUTE, or FULL; use one shared Excel input workbook to generate QUnit, OPA5, and E2E UI tests, run approved tests through real configured UI5/browser runners, and report evidence-based results. Use for Fiori app regression, navigation, bindings, accessibility, and responsive testing.
---

# Phase 6 — SAP Fiori UI Testing (Unified)

## First interaction: choose mode
If the user has **not explicitly chosen** a mode in the request, display the following and **wait for the reply before performing generation or execution**:

> Which Phase 6 UI testing mode would you like to run?
> **1 — GENERATE:** Create QUnit, OPA5 and E2E test code and cases; no SAP or test execution.
> **2 — EXECUTE:** Run existing approved tests with configured UI5/browser tools; record actual evidence.
> **3 — FULL:** Generate tests, review readiness and execute approved supported tests.

Accept `1`, `2`, `3` or `GENERATE`, `EXECUTE`, `FULL` (case-insensitive). Ask for a clear selection if the answer is ambiguous. Do not demand a mode twice when it is already specified; a `Mode` field in the workbook may supply it when the user specifically says to use the workbook selection. If a user request and workbook conflict, ask which takes precedence. No other interactive prompt implementation is assumed: use Bob's available conversation input mechanism.

## One common input workbook
All modes use `assets/SAP_Fiori_Phase6_Unified_Input_Template.xlsx`. Accept a completed copy supplied by the user. The workbook has `00 Control`, `01 App Inputs`, `02 UI Journeys`, `03 Test Data`, `04 Executor Setup`, `05 Execution Plan`, and `06 Output Register`, plus `START HERE`. Never request a separate executor workbook.

1. Confirm access to the completed workbook and application sources or generated tests, as appropriate. Do not treat illustrative example rows as real work or invent app identifiers.
2. Run `python scripts/validate_workbook.py <workbook.xlsx> --mode GENERATE|EXECUTE|FULL` where an available command runner permits. Alternatively, apply the same validations manually. Report missing fields and gaps before proceeding.
3. **GENERATE:** Require real application identity, Fiori source/manifest, relevant journey/requirements and relevant service metadata. No runtime connection needed. Data fixtures may be referenced but never embed secrets.
4. **EXECUTE:** Require generated `ui-test-manifest.json` and test sources, accessible nonproduction target, runnable commands/job references, approved test IDs and identities/fixtures. Phase 6 input workbook remains the source of execution configuration. Require explicit authorization for writes.
5. **FULL:** Require generator inputs first, then check executor prerequisites after generation. If no runner or deployed application is available, still finish generation and mark execution `BLOCKED`; never assert PASS.

## Mode: GENERATE
Read `references/ui-test-guidance.md` and `references/manifest-schema.md`. Preserve the original generator behavior:
1. Inspect actual Phase 4 Fiori source (`manifest.json`, `Component.js`, views, controllers, formatters, annotations, `package.json`) and Phase 3 OData V2/V4 definitions. Determine freestyle versus Fiori elements, UI5 version and supported runner.
2. Map user journeys/acceptance criteria to stable case and requirement IDs in `test-cases.csv`, `traceability.csv` and `coverage-summary.md`.
3. Generate appropriate QUnit isolated tests, OPA5 Page Object journeys and E2E test scripts using the project's existing runner (wdi5/Playwright). Use actual control IDs, routes and entities. Never invent bindings, auth setup, or runner commands. Add meaningful responsive, navigation, value-help, error and keyboard cases only when applicable.
4. Generate synthetic mock fixtures only when enough metadata is supplied. Mark uncertain code `NEEDS_ADAPTATION`. Preserve existing sources; do not overwrite tests without approval.
5. Create `ui-test-manifest.json` according to schema; **all cases start `NOT_RUN`**. Run `scripts/validate_manifest.py`. Deliver code, README with prerequisites, case list, traceability and coverage. Do not connect to SAP or run tests in this mode.

## Mode: EXECUTE
Read `references/execution-runbook.md` and `references/manifest-schema.md`. Preserve original executor behavior:
1. Validate the existing manifest with `scripts/validate_manifest.py`. Reconcile IDs, source paths, project version, and selected workbook execution rows.
2. Confirm real accessible nonproduction app, authorized test identity, runner (`npm` project scripts, UI5 runner, OPA5, wdi5, Playwright or CI job), browser and fixture isolation. IBM Bob/ADT by itself does **not** imply browser execution capability. Never bypass SSO/MFA or store secrets in workbook/logs.
3. Obtain explicit approval before write tests; use isolated synthetic fixtures and cleanup. Never execute on production or against real shared business records. Run non-mutating cases first using the *actual project commands* discovered, not guesses.
4. Record actual runner result, timestamp, test ID, observed/expected, log/evidence path, browser, status `PASSED`/`FAILED`/`BLOCKED`/`SKIPPED`. Scrub sensitive data from logs. Capture screenshots/trace only when permitted and supported.
5. Deliver `ui-test-results.json`, `ui-test-results.csv`, `execution-summary.md`, defect register, coverage gaps and cleanup status. Never reclassify unexecuted cases as passing. Do not silently rewrite tests to hide failures.

## Mode: FULL
1. Perform GENERATE as written and validate all generated artifacts.
2. Present the generated test scope including write effects, environment and planned commands. If necessary inputs or permissions are absent, stop execution and mark those cases `BLOCKED`, while delivering all generation artifacts.
3. Before any external execution, obtain the required authorization for selected run and any writes. Execute only through available verified runners using EXECUTE procedure.
4. Produce generation artifacts plus the observed execution report; distinguish `NOT_RUN` (not scheduled), `SKIPPED` (intentionally omitted), `BLOCKED` (prerequisites absent) and `FAILED` (real assertions failed).

## Guardrails and handoff
- Never claim an app works from generated code or examples alone.
- Do not attempt SAP/QA/CI actions without available configured tools and the right permissions.
- Require explicit permission for every data-changing test run. For nonproduction only; preserve cleanup evidence.
- Reuse source paths, stable IDs, requirements and manifest schema between all modes.
- When a field is absent, explain precisely which workbook sheet/column is missing and continue with valid nondependent work if possible.
- Final report always states mode, workbook filename, inputs used, artifacts actually created, executed case counts, observed errors and blocked dependencies.

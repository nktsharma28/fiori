# Executor runbook
1. Confirm nonproduction SAP UI app address and authorized account.
2. Confirm package scripts/runner installed and supported browser available.
3. Record runner configuration and test version/commit.
4. Run read-only tests using the project's exact QUnit/OPA5/E2E commands. Never guess commands.
5. For write tests obtain authorization, isolated fixtures and cleanup plan.
6. Record raw logs/JUnit XML/screenshots/traces when supported; redact sensitive fields.
7. Report blocked tests precisely if tools, credentials or URL are absent.
8. Generate per-case actual vs expected, timestamp, evidence path and defect recommendations.

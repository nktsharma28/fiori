# UI5 code generation guidance
- QUnit: follow project UI5 module syntax and available test runner; prefer isolated formatter and validator unit tests.
- OPA5: verify `sap.ui.test.Opa5` and Page Object conventions from the app source; use stable IDs and `waitFor` checks rather than brittle timeouts.
- E2E: use project's wdi5 or Playwright runner and compatible versions. Make authenticated browser provisioning a developer-managed task.
- MockServer: model fixtures must match genuine OData `$metadata`; distinguish mocks from integrated testing.
- Coverage: routes, bindings, application errors, roles, widths, keyboard, list/detail, regression and edge scenarios.
- Deliver source files in expected paths and add precise dependencies only if the project supports them.

# Phase 6 UI test handoff contract

Use one `ui-test-manifest.json` per application with these required fields:
- `schema_version`: `1.0`
- `phase`: `6`
- `app`: object with `id`, `ui5_version` (string or `UNKNOWN`), `base_url` (placeholder permitted), `odata_version` (`V2`, `V4`, `UNKNOWN`)
- `tests`: nonempty list of objects with `id`, `type` (`QUNIT`, `OPA5`, `E2E`), `requirement_id`, `description`, `source_path`, `runner` (`UI5`, `WDI5`, `PLAYWRIGHT`, `OTHER`), `status` (`NOT_RUN`, `PASSED`, `FAILED`, `BLOCKED`, `SKIPPED`), `expected`, `side_effects` (`NONE`, `TEST_DATA_WRITE`), `requires_approval` (boolean), `evidence` (list)
- `assumptions`: list of strings

Never mark a generated test PASSED. Execution results must come from real runner logs. Each test ID must be unique; paths must be relative, without `..` segments. No passwords, tokens, or identifiable production data.

Suggested coverage: UI5 modules, formatters, validators, bindings, list/detail routes, intents, search/filter/sort, create/edit flows where allowed, value helps, error messaging, keyboard access, responsive widths, role-based visibility, and regression-critical user journeys. Choose only relevant coverage and use real application code and annotations when available.

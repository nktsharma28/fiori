#!/usr/bin/env python3
"""Static gate for unified Phase 6 workbook. No SAP execution."""
import sys,argparse
from pathlib import Path
from openpyxl import load_workbook

def validate(path,mode):
 w=load_workbook(path,data_only=True,read_only=True)
 required_sheets=['00 Control','01 App Inputs','02 UI Journeys','03 Test Data','04 Executor Setup','05 Execution Plan','06 Output Register']
 problems=[f'Missing worksheet: {x}' for x in required_sheets if x not in w.sheetnames]
 if problems:return problems
 control=w['00 Control']; app=str(control['B5'].value or '').strip()
 if not app or app=='com.example.salesorders':problems.append('00 Control!B5: replace sample application ID')
 def has_data(sheet,key_cols,example_markers=()):
  rows=list(w[sheet].iter_rows(min_row=5,values_only=True))
  return any(all(len(r)>i and r[i] is not None and str(r[i]).strip() for i in key_cols) and not (len(r)>1 and str(r[1]).strip()=='com.example.salesorders') and not any(str(x).lower().find('example.invalid')>=0 for x in r if x is not None) for r in rows)
 if mode in ('GENERATE','FULL'):
  if not str(control['B6'].value or '').strip():problems.append('00 Control!B6: app source missing')
  if not has_data('01 App Inputs',(0,4,7)):problems.append('01 App Inputs: need App ID, manifest path and protocol')
  if not has_data('02 UI Journeys',(0,1,5,7,8)):problems.append('02 UI Journeys: need actual test ID, app, journey, steps and expected result')
 if mode=='EXECUTE':
  if not str(control['B7'].value or '').strip():problems.append('00 Control!B7: test manifest missing')
  if not str(control['B12'].value or '').strip():problems.append('00 Control!B12: test source path missing')
 if mode in ('EXECUTE','FULL'):
  if not has_data('04 Executor Setup',(0,1,2,4,6,7)):problems.append('04 Executor Setup: need real environment, app URL, runner and command')
  if not has_data('05 Execution Plan',(0,1,2,3,4,5,7)):problems.append('05 Execution Plan: need run selection and permission')
 return problems

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('workbook');p.add_argument('--mode',choices=['GENERATE','EXECUTE','FULL'],required=True);a=p.parse_args()
 try: problems=validate(a.workbook,a.mode)
 except Exception as e:sys.exit(f'Workbook validation error: {e}')
 if problems:
  print('INPUT GAPS / REVIEW:\n'+'\n'.join('- '+x for x in problems));sys.exit(1)
 print('Static workbook check passed. Example rows and real tool access must still be reviewed.')

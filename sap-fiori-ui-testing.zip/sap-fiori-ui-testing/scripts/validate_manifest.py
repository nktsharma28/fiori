#!/usr/bin/env python3
"""Static validator for Phase 6 UI test manifests. Does not execute tests."""
import json, sys
from pathlib import Path

def validate(path):
    d=json.loads(Path(path).read_text(encoding='utf-8'))
    errors=[]
    if d.get('schema_version')!='1.0' or d.get('phase')!=6: errors.append('Invalid schema_version or phase')
    a=d.get('app')
    if not isinstance(a,dict) or not all(isinstance(a.get(k),str) and a[k] for k in ('id','ui5_version','base_url','odata_version')): errors.append('Missing app fields')
    ts=d.get('tests')
    if not isinstance(ts,list) or not ts: errors.append('tests must be a nonempty list'); ts=[]
    ids=set()
    for i,t in enumerate(ts):
        prefix=f'tests[{i}]'
        if not isinstance(t,dict): errors.append(prefix+' not object');continue
        for k in ('id','requirement_id','description','source_path','expected'):
            if not isinstance(t.get(k),str) or not t[k]: errors.append(prefix+': invalid '+k)
        if t.get('id') in ids: errors.append(prefix+': duplicate ID')
        ids.add(t.get('id'))
        if t.get('type') not in ('QUNIT','OPA5','E2E'): errors.append(prefix+': invalid type')
        if t.get('runner') not in ('UI5','WDI5','PLAYWRIGHT','OTHER'): errors.append(prefix+': invalid runner')
        if t.get('status') not in ('NOT_RUN','PASSED','FAILED','BLOCKED','SKIPPED'): errors.append(prefix+': invalid status')
        if t.get('side_effects') not in ('NONE','TEST_DATA_WRITE'): errors.append(prefix+': invalid side effects')
        if not isinstance(t.get('requires_approval'),bool): errors.append(prefix+': missing approval boolean')
        if t.get('side_effects')=='TEST_DATA_WRITE' and not t.get('requires_approval'): errors.append(prefix+': write requires approval')
        if not isinstance(t.get('evidence'),list): errors.append(prefix+': invalid evidence')
        p=t.get('source_path','')
        if isinstance(p,str) and (p.startswith('/') or '..' in Path(p).parts or '\\' in p): errors.append(prefix+': unsafe path')
    if not isinstance(d.get('assumptions'),list): errors.append('assumptions must be list')
    return errors

if __name__=='__main__':
    if len(sys.argv)!=2: sys.exit('Usage: validate_manifest.py manifest.json')
    try: errs=validate(sys.argv[1])
    except Exception as e: sys.exit(f'Invalid manifest: {e}')
    if errs: print('\n'.join(errs));sys.exit(1)
    print('Manifest valid')
